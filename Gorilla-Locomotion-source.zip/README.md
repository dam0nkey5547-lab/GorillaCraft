# Gorilla Locomotion — Minecraft 1.21.5 (Fabric / QuestCraft / Vivecraft)

Gorilla Tag-style arm locomotion, ported from the supplied Unity `Player.cs`.

## STATUS: source complete, JAR NOT YET BUILT
The build sandbox had no network, no Gradle and no Minecraft/Fabric/Vivecraft jars, so the mod was
never compiled against the real game. Only `GorillaLocomotionClient.java` was type-checked against
hand-written stubs (internal consistency only). Do not treat it as tested.

## Build (produces build/libs/Gorilla-Locomotion-1.21.5.jar)
- Easiest: push this folder to a GitHub repo; the included Actions workflow builds and verifies the jar.
- Locally: JDK 21 + Gradle 8.12 → `gradle build`.

## Dependencies
Minecraft 1.21.5, Fabric Loader >=0.16.10, Fabric API 0.119.5+1.21.5, Vivecraft >=1.3.0
(compile target `maven.modrinth:vivecraft:1.21.5-1.3.7-fabric`; QuestCraft bundles its own fork).

## Install (QuestCraft)
Copy the jar into the QuestCraft 1.21.5 profile's `mods` folder (via SideQuest / the Quest file manager),
then launch the profile. Joystick walking is disabled while a VR, non-seated player is in the world.

## Known limits
Tick-rate (20 Hz) physics; no surface slip; vanilla multiplayer servers may rubber-band client movement;
Vivecraft keeps rendering the real controller position (hands are not drawn stopped at blocks).
