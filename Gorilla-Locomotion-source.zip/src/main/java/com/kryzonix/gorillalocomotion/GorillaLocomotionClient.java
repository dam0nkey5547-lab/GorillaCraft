package com.kryzonix.gorillalocomotion;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.MoverType;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import org.vivecraft.api.client.VRClientAPI;
import org.vivecraft.api.data.VRBodyPartData;
import org.vivecraft.api.data.VRPose;

import java.util.List;

/**
 * Java port of the GorillaLocomotion Player.cs algorithm (MIT, see ORIGINAL-GORILLA-LOCOMOTION-LICENSE.txt).
 * Runs once per client tick (20 Hz) using Vivecraft's real controller world positions.
 *
 * Differences from the Unity original (Minecraft has no sphere-cast/rigidbody):
 *  - hands are small AABBs swept with Entity.collideBoundingBox (axis-resolved, no tunnelling);
 *  - the "slide along surface" refinement (slipPercentage) is omitted;
 *  - launch velocity is written to the player's delta movement and then vanilla gravity/drag apply.
 */
public final class GorillaLocomotionClient implements ClientModInitializer {
    // ---- Tunables (Unity units converted: metres = blocks, seconds; one tick = 0.05 s) ----
    private static final double DT = 0.05;
    private static final double MAX_ARM_LENGTH = 1.5;
    private static final double UNSTICK_DISTANCE = 1.0;
    private static final double HAND_HALF = 0.05;      // minimumRaycastDistance
    private static final double HEAD_HALF = 0.15;
    private static final double VELOCITY_LIMIT = 0.3;  // blocks/s
    private static final double MAX_JUMP_SPEED = 6.5;  // blocks/s
    private static final double JUMP_MULTIPLIER = 1.1;
    private static final int HISTORY = 6;
    private static final double GRAVITY_STEP = 2.0 * 9.8 * DT * DT;
    private static final double EPS = 1.0E-6;

    private static boolean active;
    private static boolean init;
    private static Level lastLevel;
    private static Vec3 lastL = Vec3.ZERO, lastR = Vec3.ZERO, lastPos = Vec3.ZERO;
    private static boolean wasL, wasR;
    private static final Vec3[] history = new Vec3[HISTORY];
    private static int historyIdx;
    private static Vec3 avgVel = Vec3.ZERO;

    /** Read by the input mixin. */
    public static boolean isActive() {
        return active;
    }

    @Override
    public void onInitializeClient() {
        ClientTickEvents.END_CLIENT_TICK.register(GorillaLocomotionClient::tick);
    }

    private static void reset() {
        init = false;
        active = false;
        wasL = wasR = false;
        avgVel = Vec3.ZERO;
        for (int i = 0; i < HISTORY; i++) history[i] = Vec3.ZERO;
        historyIdx = 0;
    }

    private static void tick(Minecraft mc) {
        LocalPlayer player = mc.player;
        Level level = mc.level;
        if (player == null || level == null || mc.screen != null || mc.isPaused()
                || !player.isAlive() || player.isPassenger() || player.isSpectator()
                || player.getAbilities().flying || player.isFallFlying() || player.isSleeping()) {
            reset();
            return;
        }
        VRPose pose;
        try {
            VRClientAPI api = VRClientAPI.instance();
            if (api == null || !api.isVRInitialized() || !api.isVRActive()) { reset(); return; }
            pose = api.getPreTickWorldPose();
        } catch (Throwable t) { // Vivecraft absent / API mismatch: stay inactive, vanilla movement untouched
            reset();
            return;
        }
        if (pose == null || pose.isSeated()) { reset(); return; }
        VRBodyPartData main = pose.getMainHand(), off = pose.getOffHand(), headData = pose.getHead();
        if (main == null || off == null || headData == null) { reset(); return; }
        boolean lefty = pose.isLeftHanded();
        Vec3 rawL = (lefty ? main : off).getPos();
        Vec3 rawR = (lefty ? off : main).getPos();
        Vec3 head = headData.getPos();
        if (!finite(rawL) || !finite(rawR) || !finite(head)) { reset(); return; }

        if (!init || level != lastLevel) {
            lastLevel = level;
            lastL = clampArm(rawL, head);
            lastR = clampArm(rawR, head);
            lastPos = player.position();
            wasL = wasR = false;
            avgVel = Vec3.ZERO;
            for (int i = 0; i < HISTORY; i++) history[i] = Vec3.ZERO;
            init = true;
            active = true;
            return;
        }
        active = true;

        Vec3 curL = clampArm(rawL, head);
        Vec3 curR = clampArm(rawR, head);
        Vec3 gravity = new Vec3(0, -GRAVITY_STEP, 0);

        // ---- first pass: hand collision, stick-to-surface displacement ----
        boolean lCol = false, rCol = false;
        Vec3 firstL = Vec3.ZERO, firstR = Vec3.ZERO;
        Vec3 end = cast(level, player, lastL, curL.subtract(lastL).add(gravity));
        if (end != null) {
            firstL = wasL ? lastL.subtract(curL) : end.subtract(curL);
            lCol = true;
        }
        end = cast(level, player, lastR, curR.subtract(lastR).add(gravity));
        if (end != null) {
            firstR = wasR ? lastR.subtract(curR) : end.subtract(curR);
            rCol = true;
        }
        if (lCol || rCol) player.setDeltaMovement(Vec3.ZERO);

        boolean both = (lCol || wasL) && (rCol || wasR);
        Vec3 move = both ? firstL.add(firstR).scale(0.5) : firstL.add(firstR);

        // ---- head must not enter geometry ----
        Vec3 actual = Vec3.ZERO;
        if (move.lengthSqr() > EPS) {
            move = Entity.collideBoundingBox(player, move, box(head, HEAD_HALF), level, List.of());
            if (move.lengthSqr() > EPS) {
                Vec3 before = player.position();
                player.move(MoverType.SELF, move);
                actual = player.position().subtract(before);
            }
        }
        // the rig moved, so tracked hands/head moved with it
        head = head.add(actual);
        curL = curL.add(actual);
        curR = curR.add(actual);

        // ---- final hand follower positions ----
        end = cast(level, player, lastL, curL.subtract(lastL));
        if (end != null) { lastL = end; lCol = true; } else { lastL = curL; }
        end = cast(level, player, lastR, curR.subtract(lastR));
        if (end != null) { lastR = end; rCol = true; } else { lastR = curR; }

        // ---- velocity history / launch ----
        Vec3 pos = player.position();
        Vec3 current = pos.subtract(lastPos).scale(1.0 / DT);
        historyIdx = (historyIdx + 1) % HISTORY;
        avgVel = avgVel.add(current.subtract(history[historyIdx]).scale(1.0 / HISTORY));
        history[historyIdx] = current;
        lastPos = pos;

        if (lCol || rCol) {
            double speed = avgVel.length();
            if (speed > VELOCITY_LIMIT) {
                Vec3 v = speed * JUMP_MULTIPLIER > MAX_JUMP_SPEED
                        ? avgVel.normalize().scale(MAX_JUMP_SPEED)
                        : avgVel.scale(JUMP_MULTIPLIER);
                player.setDeltaMovement(v.scale(DT)); // blocks/tick
            }
        }

        // ---- unstick if the hand was left far behind and nothing blocks the arm ----
        if (lCol && curL.distanceTo(lastL) > UNSTICK_DISTANCE && armClear(level, player, head, curL)) {
            lastL = curL;
            lCol = false;
        }
        if (rCol && curR.distanceTo(lastR) > UNSTICK_DISTANCE && armClear(level, player, head, curR)) {
            lastR = curR;
            rCol = false;
        }
        wasL = lCol;
        wasR = rCol;
    }

    /** Returns the position the hand ends at if it hits a block, or null if the move is free. */
    private static Vec3 cast(Level level, Entity e, Vec3 start, Vec3 delta) {
        AABB box = box(start, HAND_HALF);
        double len = delta.length();
        if (len < EPS) {
            return level.getBlockCollisions(e, box.inflate(0.01)).iterator().hasNext() ? start : null;
        }
        Vec3 allowed = Entity.collideBoundingBox(e, delta, box, level, List.of());
        if (allowed.distanceToSqr(delta) > EPS) {
            return start.add(allowed);
        }
        // already resting on a surface we are moving into (Unity's "smaller spherecast" sanity check)
        Vec3 probe = delta.scale((len + 0.02) / len);
        Vec3 probed = Entity.collideBoundingBox(e, probe, box, level, List.of());
        return probed.distanceToSqr(probe) > EPS ? start : null;
    }

    private static boolean armClear(Level level, Entity e, Vec3 head, Vec3 hand) {
        return level.clip(new ClipContext(head, hand, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, e))
                .getType() == HitResult.Type.MISS;
    }

    private static Vec3 clampArm(Vec3 hand, Vec3 head) {
        Vec3 d = hand.subtract(head);
        double l = d.length();
        return l < MAX_ARM_LENGTH ? hand : head.add(d.scale(MAX_ARM_LENGTH / l));
    }

    private static AABB box(Vec3 c, double h) {
        return new AABB(c.x - h, c.y - h, c.z - h, c.x + h, c.y + h, c.z + h);
    }

    private static boolean finite(Vec3 v) {
        return Double.isFinite(v.x) && Double.isFinite(v.y) && Double.isFinite(v.z);
    }
}
