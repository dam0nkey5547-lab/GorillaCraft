package com.kryzonix.gorillalocomotion.mixin;

import com.kryzonix.gorillalocomotion.GorillaLocomotionClient;
import net.minecraft.client.player.ClientInput;
import net.minecraft.client.player.KeyboardInput;
import net.minecraft.world.entity.player.Input;
import net.minecraft.world.phys.Vec2;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Removes joystick/WASD walking while arm locomotion is active. Jump/sneak/sprint flags are kept. */
@Mixin(value = KeyboardInput.class, priority = 2000)
public abstract class KeyboardInputMixin extends ClientInput {
    @Inject(method = "tick", at = @At("TAIL"))
    private void gorilla$suppressWalking(CallbackInfo ci) {
        if (GorillaLocomotionClient.isActive()) {
            Input k = this.keyPresses;
            this.keyPresses = new Input(false, false, false, false, k.jump(), k.shift(), false);
            this.moveVector = Vec2.ZERO;
        }
    }
}
